-- uncatalog ALL

uncatalog dcs db HBFBDB2;
uncatalog dcs db HBFDDB2;
uncatalog dcs db HBFHDB2;
uncatalog dcs db HBFIDB2;
uncatalog dcs db HBFRDB2;
uncatalog dcs db HBFTDB2;

uncatalog db HBFBDB2;
uncatalog db HBFDDB2;
uncatalog db HBFHDB2;
uncatalog db HBFIDB2;
uncatalog db HBFRDB2;
uncatalog db HBFTDB2;

uncatalog node HBFBDB2;
uncatalog node HBFDDB2;
uncatalog node HBFHDB2;
uncatalog node HBFIDB2;
uncatalog node HBFRDB2;
uncatalog node HBFTDB2;

uncatalog system odbc data source HBFBDB2;
uncatalog system odbc data source HBFDDB2;
uncatalog system odbc data source HBFHDB2;
uncatalog system odbc data source HBFIDB2;
uncatalog system odbc data source HBFRDB2;
uncatalog system odbc data source HBFTDB2;

terminate;