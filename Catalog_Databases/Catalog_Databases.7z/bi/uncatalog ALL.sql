-- uncatalog ALL bi

uncatalog db DB_EDWDD;
uncatalog db DB_EDWDP;
uncatalog db DB_EDWDR;
uncatalog db DB_EDWLD;
uncatalog db DB_EDWLP;
uncatalog db DB_EDWLR;
uncatalog db DB_EDWSD;
uncatalog db DB_EDWSP;
uncatalog db DB_EDWSR;
uncatalog db DB_INFO;
uncatalog db DB_INFOZ;
uncatalog db DB_RDSD;
uncatalog db DB_RDSP;
uncatalog db DB_RDSR;
uncatalog db PRDOBIEE;

uncatalog system odbc data source DB_EDWDD;
uncatalog system odbc data source DB_EDWDP;
uncatalog system odbc data source DB_EDWDR;
uncatalog system odbc data source DB_EDWLD;
uncatalog system odbc data source DB_EDWLP;
uncatalog system odbc data source DB_EDWLR;
uncatalog system odbc data source DB_EDWSD;
uncatalog system odbc data source DB_EDWSP;
uncatalog system odbc data source DB_EDWSR;
uncatalog system odbc data source DB_INFO;
uncatalog system odbc data source DB_INFOZ;
uncatalog system odbc data source DB_RDSD;
uncatalog system odbc data source DB_RDSP;
uncatalog system odbc data source DB_RDSR;
uncatalog system odbc data source PRDOBIEE;

uncatalog node DB2EDWD2;
uncatalog node DB2EDWP2;
uncatalog node DB2EDWR2;
uncatalog node DB2INFO2;
uncatalog node DB2LEG2;
uncatalog node DB2OBIEE;
uncatalog node DB2RDS2;
uncatalog node DB2RDSR2;

terminate;