-- uncatalog ALL Siebel

uncatalog db SIEBADM3;
uncatalog db SIEBDEV1;
uncatalog db SIEBDEV3;
uncatalog db SIEBINT;
uncatalog db SIEBPRD;
uncatalog db SIEBRLS;
uncatalog db SIEBSIT2;
uncatalog db SIEBSIT3;
uncatalog db SIEBTRN;

uncatalog node DB2SIEA3;
uncatalog node DB2SIEB;
uncatalog node DB2SIEBI;
uncatalog node DB2SIEBR;
uncatalog node DB2SIEBT;
uncatalog node DB2SIED1;
uncatalog node DB2SIED3;
uncatalog node DB2SIES2;
uncatalog node DB2SIES3;

uncatalog system odbc data source SIEBADM3;
uncatalog system odbc data source SIEBDEV1;
uncatalog system odbc data source SIEBDEV3;
uncatalog system odbc data source SIEBINT;
uncatalog system odbc data source SIEBPRD;
uncatalog system odbc data source SIEBRLS;
uncatalog system odbc data source SIEBSIT2;
uncatalog system odbc data source SIEBSIT3;
uncatalog system odbc data source SIEBTRN;

terminate;